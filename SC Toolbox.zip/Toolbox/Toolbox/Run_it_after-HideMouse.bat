HideMouse-First.exe /hide
HideMouse-First.exe /hide
